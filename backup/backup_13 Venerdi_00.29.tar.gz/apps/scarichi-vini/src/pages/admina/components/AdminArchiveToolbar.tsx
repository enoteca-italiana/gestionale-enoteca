import type { Filters, StockFilter } from '@/pages/admina/types';

type Props = {
  winesCount: number;
  availableCount: number;
  outCount: number;
  filters: Filters;
  categories: string[];
  onFiltersChange: (next: Filters) => void;
  onRequestAddCategory: (onResult: (created: string | null) => void) => void;
  onOpenCreate: () => void;
};

export function AdminArchiveToolbar({
  winesCount,
  availableCount,
  outCount,
  filters,
  categories,
  onFiltersChange,
  onRequestAddCategory,
  onOpenCreate
}: Props) {
  return (
    <section className="archiveTopBar">
      <div className="archiveFilters">
        <input
          className="input archiveFilterControl"
          placeholder="Cerca per nome, produttore, provenienza, note…"
          value={filters.term}
          onChange={(e) => onFiltersChange({ ...filters, term: e.target.value })}
        />

        <select
          className="input archiveFilterControl"
          value={filters.category}
          onChange={(e) => {
            const value = e.target.value;
            if (value === '__add_category__') {
              onRequestAddCategory((created) => {
                onFiltersChange({ ...filters, category: created ?? 'all' });
              });
              return;
            }
            onFiltersChange({ ...filters, category: value });
          }}
        >
          <option value="all">Tutte le categorie</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
          <option value="__add_category__">+ Aggiungi categoria…</option>
        </select>

        <select
          className="input archiveFilterControl"
          value={filters.stock}
          onChange={(e) => onFiltersChange({ ...filters, stock: e.target.value as StockFilter })}
        >
          <option value="all">Tutte le giacenze</option>
          <option value="available">Disponibili</option>
          <option value="out">Esauriti</option>
        </select>

        <div className="archiveStatsBox" aria-label="Riepilogo vini">
          <div className="archiveStatsItem archiveStatsItemTotal">
            <div className="archiveStatLabel">Totale</div>
            <div className="archiveStatValue">{winesCount}</div>
          </div>
          <div className="archiveStatsItem archiveStatsItemAvailable">
            <div className="archiveStatLabel">Disponibili</div>
            <div className="archiveStatValue">{availableCount}</div>
          </div>
          <div className="archiveStatsItem archiveStatsItemOut">
            <div className="archiveStatLabel">Esauriti</div>
            <div className="archiveStatValue">{outCount}</div>
          </div>
        </div>

        <button className="button buttonAuto archiveAddButton" type="button" onClick={onOpenCreate}>
          Aggiungi vino
        </button>
      </div>
    </section>
  );
}
