export type WineId = string;

export type Wine = {
  id: WineId;
  name: string;
  producer: string;
  origin: string;
  vintage?: string;
  qty: number;
};

export type SessionItem = {
  wineId: WineId;
  qty: number;
};
