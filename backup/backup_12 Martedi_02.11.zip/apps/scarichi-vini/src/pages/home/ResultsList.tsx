import type { Wine } from '@/domain/types';

export function ResultsList({
  wines,
  onQuickRemove
}: {
  wines: Wine[];
  onQuickRemove: (wineId: string, amount: 1 | 2 | 3) => void;
}) {
  return (
    <div className="card mt12">
      <div className="sectionTitle">Risultati</div>
      <div className="subtle mt6">Tocca un vino e usa i pulsanti rapidi.</div>
      <div className="list mt12">
        {wines.map((w) => {
          const disabled = w.qty <= 0;
          return (
            <div key={w.id} className="listItem">
              <div className="row">
                <div className="min0">
                  <div className="lineTitle">{w.name}</div>
                  <div className="subtle mt4">
                    {w.producer} • {w.origin}
                    {w.vintage ? ` • ${w.vintage}` : ''}
                  </div>
                </div>
                <div className={`pill ${disabled ? 'pillDanger' : ''}`}>Q.tà {w.qty}</div>
              </div>
              <div className="quickButtons mt10">
                <button className="smallButton" type="button" disabled={disabled} onClick={() => onQuickRemove(w.id, 1)}>
                  -1
                </button>
                <button className="smallButton" type="button" disabled={disabled} onClick={() => onQuickRemove(w.id, 2)}>
                  -2
                </button>
                <button className="smallButton" type="button" disabled={disabled} onClick={() => onQuickRemove(w.id, 3)}>
                  -3
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
