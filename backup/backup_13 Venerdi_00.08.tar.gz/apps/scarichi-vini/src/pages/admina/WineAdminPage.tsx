import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Wine } from '@/domain/types';
import { ConfirmModal } from '@/components/ConfirmModal';
import { createWine, deleteWine, listWines, updateWine } from '@/data/wineRepository';
import { AdminArchiveToolbar } from '@/pages/admina/components/AdminArchiveToolbar';
import { AdminArchiveTable } from '@/pages/admina/components/AdminArchiveTable';
import { WineArchiveFormModal } from '@/pages/admina/components/WineArchiveFormModal';
import {
  defaultFilters,
  emptyWine,
  type Filters,
  type Mode,
  type WineFormState
} from '@/pages/admina/types';

function matchesFilters(wine: Wine, filters: Filters) {
  const term = filters.term.trim().toLowerCase();
  if (term) {
    const haystack = [
      wine.category,
      wine.name,
      wine.age,
      wine.producer,
      wine.origin,
      wine.notes,
      wine.warehouse
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();
    if (!haystack.includes(term)) return false;
  }

  if (filters.category !== 'all') {
    const category = wine.category?.toLowerCase() ?? '';
    if (category !== filters.category.toLowerCase()) return false;
  }

  if (filters.stock === 'available' && wine.qty <= 0) return false;
  if (filters.stock === 'out' && wine.qty > 0) return false;
  return true;
}

export function WineAdminPage() {
  const [wines, setWines] = useState<Wine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<Filters>(defaultFilters);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<Mode>('create');
  const [formState, setFormState] = useState<WineFormState>(emptyWine);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const loadWines = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setWines(await listWines());
    } catch (err) {
      console.error('[WineAdminPage] load error', err);
      setError('Impossibile caricare i vini. Verifica connessione/Supabase.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadWines();
  }, [loadWines]);

  const categories = useMemo(() => {
    const set = new Set<string>();
    wines.forEach((w) => {
      if (w.category) set.add(w.category);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'it', { sensitivity: 'base' }));
  }, [wines]);

  const filteredWines = useMemo(
    () => wines.filter((w) => matchesFilters(w, filters)),
    [wines, filters]
  );

  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2400);
  };

  const openCreate = () => {
    setModalMode('create');
    setFormState(emptyWine);
    setModalOpen(true);
  };

  const openEdit = (wine: Wine) => {
    setModalMode('edit');
    setFormState({ ...wine });
    setModalOpen(true);
  };

  const closeForm = () => {
    setModalOpen(false);
    setFormState(emptyWine);
  };

  const handleSubmit = async (payload: WineFormState) => {
    setBusy(true);
    try {
      if (modalMode === 'create') {
        await createWine({ ...payload, id: undefined });
        showToast('Vino aggiunto');
      } else {
        await updateWine(payload);
        showToast('Vino aggiornato');
      }
      await loadWines();
      closeForm();
    } catch (err) {
      console.error('[WineAdminPage] submit error', err);
      setError('Operazione non riuscita. Riprova.');
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setBusy(true);
    try {
      await deleteWine(deleteId);
      await loadWines();
      showToast('Vino eliminato');
    } catch (err) {
      console.error('[WineAdminPage] delete error', err);
      setError('Eliminazione non riuscita.');
    } finally {
      setBusy(false);
      setDeleteId(null);
    }
  };

  return (
    <div className="container archiveDesktopContainer">
      <div className="archiveLogoTop">
        <img
          className="archiveLogoImg"
          src="/logo.png"
          alt="Enoteca Italiana"
          loading="lazy"
          decoding="async"
          width={1024}
          height={240}
        />
      </div>

      <AdminArchiveToolbar
        winesCount={wines.length}
        availableCount={wines.filter((w) => w.qty > 0).length}
        outCount={wines.filter((w) => w.qty <= 0).length}
        filters={filters}
        categories={categories}
        onFiltersChange={setFilters}
        onOpenCreate={openCreate}
      />

      {error ? (
        <div className="card adminCard mt12 adminError">
          <div className="lineTitle">{error}</div>
        </div>
      ) : null}

      <AdminArchiveTable
        wines={filteredWines}
        loading={loading}
        onEdit={openEdit}
        onDelete={setDeleteId}
      />

      <WineArchiveFormModal
        open={modalOpen}
        mode={modalMode}
        busy={busy}
        initial={formState}
        onSubmit={handleSubmit}
        onCancel={closeForm}
      />

      <ConfirmModal
        open={deleteId !== null}
        title="Eliminare il vino?"
        description="L'operazione aggiorna Supabase e la sync di backup."
        confirmLabel={busy ? 'Elimino…' : 'Elimina'}
        cancelLabel="Annulla"
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
      />

      {toast ? (
        <div className="mt12">
          <div className="toastInline">{toast}</div>
        </div>
      ) : null}
    </div>
  );
}
