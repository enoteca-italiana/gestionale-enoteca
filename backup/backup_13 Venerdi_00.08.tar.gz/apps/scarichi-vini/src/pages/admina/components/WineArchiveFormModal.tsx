import { useEffect, useMemo, useState } from 'react';
import type { Mode, WineFormState } from '@/pages/admina/types';

type Props = {
  open: boolean;
  mode: Mode;
  busy: boolean;
  initial: WineFormState;
  onSubmit: (wine: WineFormState) => Promise<void>;
  onCancel: () => void;
};

function asNumber(value: string): number | undefined {
  const normalized = value.replace(',', '.').trim();
  if (!normalized) return undefined;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : undefined;
}

export function WineArchiveFormModal({ open, mode, busy, initial, onSubmit, onCancel }: Props) {
  const [state, setState] = useState<WineFormState>(initial);
  const [error, setError] = useState<string | null>(null);
  const yearOptions = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const years: string[] = [];
    for (let year = currentYear; year >= 1900; year -= 1) {
      years.push(String(year));
    }
    return years;
  }, []);

  useEffect(() => {
    if (open) {
      setState(initial);
      setError(null);
    }
  }, [open, initial]);

  const canSubmit = useMemo(() => {
    return (
      state.name.trim().length > 0 &&
      state.producer.trim().length > 0 &&
      state.origin.trim().length > 0
    );
  }, [state.name, state.origin, state.producer]);

  if (!open) return null;

  const setField = (key: keyof WineFormState, value: string) => {
    setState((prev) => ({ ...prev, [key]: value }));
  };

  const setNumericField = (key: keyof WineFormState, value: string) => {
    setState((prev) => ({ ...prev, [key]: asNumber(value) }));
  };

  const submit = async () => {
    if (!canSubmit || busy) return;
    try {
      await onSubmit({
        ...state,
        qty: Number.isFinite(state.qty) ? Math.max(0, Math.round(state.qty)) : 0
      });
    } catch (err) {
      console.error('[WineArchiveFormModal] submit error', err);
      setError('Salvataggio non riuscito. Riprova.');
    }
  };

  return (
    <div className="modalOverlay" role="dialog" aria-modal="true">
      <div className="modalCard archiveModalCard">
        <div className="modalTitle">{mode === 'create' ? 'Aggiungi vino' : 'Modifica vino'}</div>

        <div className="archiveFormGrid mt12">
          <label className="modalLabel">
            Categoria
            <input
              className="input mt4"
              value={state.category ?? ''}
              onChange={(e) => setField('category', e.target.value)}
            />
          </label>
          <label className="modalLabel archiveFormSpan2">
            Nome
            <input
              className="input mt4"
              value={state.name}
              onChange={(e) => setField('name', e.target.value)}
            />
          </label>
          <label className="modalLabel">
            Anno
            <select
              className="input mt4"
              value={state.age ?? ''}
              onChange={(e) => setField('age', e.target.value)}
            >
              <option value="">Seleziona anno</option>
              {yearOptions.map((year) => (
                <option key={year} value={year}>
                  {year}
                </option>
              ))}
            </select>
          </label>

          <label className="modalLabel">
            Produttore
            <input
              className="input mt4"
              value={state.producer}
              onChange={(e) => setField('producer', e.target.value)}
            />
          </label>
          <label className="modalLabel">
            Provenienza
            <input
              className="input mt4"
              value={state.origin}
              onChange={(e) => setField('origin', e.target.value)}
            />
          </label>
          <div className="archiveFormInline3">
            <label className="modalLabel archiveFormQtyLabel">
              Q.tà
              <input
                className="input mt4 archiveFormQtyInput"
                type="number"
                inputMode="numeric"
                min={0}
                max={99}
                step={1}
                value={state.qty}
                onChange={(e) => {
                  const parsed = Number(e.target.value);
                  if (!Number.isFinite(parsed)) return;
                  const nextQty = Math.max(0, Math.min(99, Math.round(parsed)));
                  setState((prev) => ({ ...prev, qty: nextQty }));
                }}
              />
            </label>
            <label className="modalLabel">
              Acquisto
              <div className="archiveCurrencyInputWrap mt4">
                <span className="archiveCurrencyPrefix" aria-hidden="true">
                  €
                </span>
                <input
                  className="input archiveCurrencyInput"
                  inputMode="decimal"
                  value={state.purchasePrice ?? ''}
                  onChange={(e) => setNumericField('purchasePrice', e.target.value)}
                />
              </div>
            </label>
            <label className="modalLabel">
              Vendita
              <div className="archiveCurrencyInputWrap mt4">
                <span className="archiveCurrencyPrefix" aria-hidden="true">
                  €
                </span>
                <input
                  className="input archiveCurrencyInput"
                  inputMode="decimal"
                  value={state.salePrice ?? ''}
                  onChange={(e) => setNumericField('salePrice', e.target.value)}
                />
              </div>
            </label>
          </div>
          <label className="modalLabel archiveFormSpan2">
            Note
            <textarea
              className="input mt4 archiveNotesInput"
              value={state.notes ?? ''}
              onChange={(e) => setField('notes', e.target.value)}
              rows={2}
            />
          </label>
        </div>

        {error ? <div className="errorText mt8">{error}</div> : null}

        <div className="modalActions archiveModalActions">
          <button
            className="button buttonSecondary archiveModalActionButton"
            type="button"
            onClick={onCancel}
            disabled={busy}
          >
            Annulla
          </button>
          <button
            className="button archiveModalActionButton"
            type="button"
            onClick={submit}
            disabled={!canSubmit || busy}
          >
            {busy ? 'Salvo…' : 'Salva'}
          </button>
        </div>
      </div>
    </div>
  );
}
