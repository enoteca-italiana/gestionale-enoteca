import type { Wine } from '@/domain/types';
import { supabase } from '@/lib/supabase';
import { loadDb, notifyDbChanged, saveDb, newId } from '@/data/localDb';
import { syncWineUpsert, syncWineDelete } from '@/integrations/googleSheetsSync';

type WineRow = {
  id: string;
  category?: string | null;
  name: string;
  age?: string | null;
  producer: string;
  origin: string;
  purchase_price?: number | null;
  sale_price?: number | null;
  vintage?: string | null;
  qty?: number | null;
  warehouse?: number | null;
  margin?: number | null;
  notes?: string | null;
};

function toWine(row: WineRow): Wine {
  const purchase = typeof row.purchase_price === 'number' ? row.purchase_price : undefined;
  const sale = typeof row.sale_price === 'number' ? row.sale_price : undefined;
  const qty = Number(row.qty ?? 0);
  const margin =
    typeof row.margin === 'number'
      ? row.margin
      : purchase !== undefined && sale !== undefined
        ? sale - purchase
        : undefined;
  const warehouse =
    typeof row.warehouse === 'number'
      ? row.warehouse
      : purchase !== undefined && Number.isFinite(qty)
        ? purchase * qty
        : undefined;

  return {
    id: row.id,
    category: row.category ?? undefined,
    name: row.name,
    age: row.age ?? undefined,
    producer: row.producer,
    origin: row.origin,
    purchasePrice: purchase,
    salePrice: sale,
    vintage: row.vintage ?? undefined,
    qty,
    warehouse: warehouse !== undefined ? Number(warehouse.toFixed(2)) : undefined,
    margin: margin !== undefined ? Number(margin.toFixed(2)) : undefined,
    notes: row.notes ?? undefined
  };
}

function toRowPayload(wine: Wine) {
  const computedMargin =
    wine.purchasePrice !== undefined && wine.salePrice !== undefined
      ? Number((wine.salePrice - wine.purchasePrice).toFixed(2))
      : null;
  const computedWarehouse =
    wine.purchasePrice !== undefined
      ? Number((wine.purchasePrice * Math.max(0, Math.round(wine.qty))).toFixed(2))
      : null;

  return {
    id: wine.id,
    category: wine.category ?? null,
    name: wine.name,
    age: wine.age ?? null,
    producer: wine.producer,
    origin: wine.origin,
    purchase_price: wine.purchasePrice ?? null,
    sale_price: wine.salePrice ?? null,
    vintage: wine.vintage ?? null,
    qty: wine.qty,
    warehouse: computedWarehouse,
    margin: computedMargin,
    notes: wine.notes ?? null
  };
}

function toLegacyPayload(wine: Wine) {
  return {
    id: wine.id,
    name: wine.name,
    producer: wine.producer,
    origin: wine.origin,
    vintage: wine.vintage ?? null,
    category: wine.category ?? null,
    qty: wine.qty
  };
}

function isSchemaColumnError(error: unknown): boolean {
  const message = String(
    (error as { message?: unknown } | null | undefined)?.message ?? ''
  ).toLowerCase();
  return message.includes('column') && message.includes('does not exist');
}

function sortWines(wines: Wine[]): Wine[] {
  return [...wines].sort((a, b) => a.name.localeCompare(b.name, 'it', { sensitivity: 'base' }));
}

function getLocalInventory(): Wine[] {
  return loadDb().inventory;
}

function persistLocalInventory(next: Wine[]) {
  const db = loadDb();
  saveDb({ ...db, inventory: next });
  notifyDbChanged();
}

export async function listWines(): Promise<Wine[]> {
  if (supabase) {
    const { data, error } = await supabase.from('wines').select('*');
    if (error) {
      console.error('[wineRepository] Supabase list error', error);
      return sortWines(getLocalInventory());
    }
    const wines = (data ?? []).map(toWine);
    persistLocalInventory(wines);
    return sortWines(wines);
  }

  return sortWines(getLocalInventory());
}

export type WineInput = {
  id?: string;
  category?: string;
  name: string;
  age?: string;
  producer: string;
  origin: string;
  purchasePrice?: number;
  salePrice?: number;
  vintage?: string;
  qty: number;
  notes?: string;
};

function normalizeInput(input: WineInput): Wine {
  const purchasePrice = Number(input.purchasePrice);
  const salePrice = Number(input.salePrice);
  const qty = Number.isFinite(input.qty) ? Math.max(0, Math.round(input.qty)) : 0;
  const hasPurchase = Number.isFinite(purchasePrice);
  const hasSale = Number.isFinite(salePrice);
  const margin =
    hasPurchase && hasSale ? Number((salePrice - purchasePrice).toFixed(2)) : undefined;
  const warehouse = hasPurchase ? Number((purchasePrice * qty).toFixed(2)) : undefined;

  return {
    id: input.id ?? newId('wine'),
    category: input.category?.trim() || undefined,
    name: input.name.trim(),
    age: input.age?.trim() || undefined,
    producer: input.producer.trim(),
    origin: input.origin.trim(),
    purchasePrice: hasPurchase ? purchasePrice : undefined,
    salePrice: hasSale ? salePrice : undefined,
    vintage: input.vintage?.trim() || undefined,
    qty,
    warehouse,
    margin,
    notes: input.notes?.trim() || undefined
  };
}

export async function createWine(input: WineInput): Promise<Wine> {
  let wine = normalizeInput({ ...input, id: undefined });

  if (supabase) {
    const { data, error } = await supabase
      .from('wines')
      .insert(toRowPayload(wine))
      .select()
      .single();
    if (error && isSchemaColumnError(error)) {
      const legacy = await supabase.from('wines').insert(toLegacyPayload(wine)).select().single();
      if (legacy.error) {
        console.error('[wineRepository] Supabase create legacy error', legacy.error);
        throw legacy.error;
      }
      wine = toWine(legacy.data);
    } else if (error) {
      console.error('[wineRepository] Supabase create error', error);
      throw error;
    } else {
      wine = toWine(data);
    }
  }

  const next = sortWines([...getLocalInventory().filter((w) => w.id !== wine.id), wine]);
  persistLocalInventory(next);
  await syncWineUpsert(wine);
  return wine;
}

export async function updateWine(input: WineInput): Promise<Wine> {
  if (!input.id) throw new Error('Missing wine id');
  let wine = normalizeInput(input);

  if (supabase) {
    const { data, error } = await supabase
      .from('wines')
      .update(toRowPayload(wine))
      .eq('id', wine.id)
      .select()
      .single();
    if (error && isSchemaColumnError(error)) {
      const legacy = await supabase
        .from('wines')
        .update(toLegacyPayload(wine))
        .eq('id', wine.id)
        .select()
        .single();
      if (legacy.error) {
        console.error('[wineRepository] Supabase update legacy error', legacy.error);
        throw legacy.error;
      }
      wine = toWine(legacy.data);
    } else if (error) {
      console.error('[wineRepository] Supabase update error', error);
      throw error;
    } else {
      wine = toWine(data);
    }
  }

  const next = sortWines([...getLocalInventory().filter((w) => w.id !== wine.id), wine]);
  persistLocalInventory(next);
  await syncWineUpsert(wine);
  return wine;
}

export async function deleteWine(id: string): Promise<void> {
  if (supabase) {
    const { error } = await supabase.from('wines').delete().eq('id', id);
    if (error) {
      console.error('[wineRepository] Supabase delete error', error);
      throw error;
    }
  }

  const next = getLocalInventory().filter((w) => w.id !== id);
  persistLocalInventory(next);
  await syncWineDelete(id);
}
