# Scarichi Vini (PWA)

App frontend del progetto Enoteca (workspace `@enoteca/scarichi-vini`).

Ultimo aggiornamento: **13/03/2026 00:07 CET**.

## Quick Start

Dalla root del monorepo:

```bash
npm install
npm run dev
```

Comandi utili:

- `npm run build`
- `npm run preview`
- `npm run dev -w @enoteca/scarichi-vini -- --port 5001` (porta dedicata)

## Funzionalità principali

- Sessione scarico mobile-first (`/`) con supporto offline.
- Admin impostazioni (`/admin`) con autenticazione locale.
- Archivio vini desktop-first (`/admina`) con CRUD completo:
  - colonne estese (categoria, anno, prezzi, q.tà, note)
  - toolbar filtri ottimizzata su una riga desktop con box statistiche compatto (`Totale`, `Disponibili`, `Esauriti`)
  - `Disponibili` in tono verde, `Esauriti` in tono rosso
  - q.tà `0` evidenziata in rosso acceso
  - calcoli automatici:
    - `Magazzino = Acquisto × Q.tà`
    - `Margine = Vendita − Acquisto`
- Logo applicativo ottimizzato in `public/logo.png` per ridurre peso asset.

## Setup su un altro PC

1. Clona il repo.
2. Verifica Node LTS 20.x (`node -v`).
3. Esegui `npm install` dalla root.
4. Avvia `npm run dev`.
5. Se porta occupata: `lsof -iTCP:5173 -sTCP:LISTEN`.
6. Se UI stale in PWA: hard refresh o rimozione SW/PWA installata.

## Variabili ambiente

- Crea `.env` da `.env.example`.
- In assenza di configurazione Supabase, l’app resta operativa in modalità locale (localStorage + seed vini).
