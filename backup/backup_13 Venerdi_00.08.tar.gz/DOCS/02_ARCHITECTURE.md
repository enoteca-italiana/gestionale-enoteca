# Architettura

Ultimo aggiornamento: **13/03/2026 00:07 CET**.

## Workspace

- Root `package.json` con npm workspaces.
- App principale: `apps/scarichi-vini/`.

## Stack

- Vite + React 18
- Routing: `wouter`
- PWA: `vite-plugin-pwa`

## Routing

- `/` → `HomePage`
- `/admin` → `AdminPage`
- `/admina` → `WineAdminPage` (archivio vini, desktop-first)

## Moduli chiave

### UI

- `src/components/`
  - `Logo.tsx`
  - `BottomNav.tsx`
  - `ConfirmModal.tsx`
  - `Toast.tsx`

Asset logo:

- `apps/scarichi-vini/public/logo.png` (asset unico usato in UI, ottimizzato).
- `Logo.tsx` usa direttamente `logo.png`.

### Pagine

- `src/pages/HomePage.tsx`
- `src/pages/AdminPage.tsx`
- `src/pages/admina/WineAdminPage.tsx`

### Home (sessione)

- `src/pages/home/`
  - `ResultsList.tsx`
  - `SummaryList.tsx`
  - `SessionConfirmModal.tsx`
  - `useLocalSession.ts`

### Admin

- `src/pages/admin/`
  - `AdminGate.tsx`
  - `AdminLogin.tsx`
  - `AdminHome.tsx`
  - `AdminSettings.tsx`
  - `AdminHistory.tsx`
  - `AdminPending.tsx`
  - `useAdminAuth.ts`
  - `storage.ts`

### Admin archivio vini (`/admina`)

- `src/pages/admina/`
  - `WineAdminPage.tsx`
  - `types.ts`
  - `components/AdminArchiveToolbar.tsx`
  - `components/AdminArchiveTable.tsx`
  - `components/WineArchiveFormModal.tsx`

Toolbar archivio:

- filtri ottimizzati su una riga desktop;
- box compatto statistiche (`Totale`, `Disponibili`, `Esauriti`) tra filtro giacenze e CTA `Aggiungi vino`;
- indicatori: `Disponibili` in tono verde, `Esauriti` in tono rosso.

### Dati locali

- `src/data/localDb.ts`
- `src/data/useLocalDb.ts`
- `src/data/mockWines.ts` (seed + dataset test)
- `src/data/wineRepository.ts` (CRUD locale/Supabase con fallback schema legacy)

### Settings runtime

- `src/app/useAppSettings.ts`
- `src/app/useOnlineStatus.ts`

## Invarianti (da rispettare)

- File funzionali lunghi: **max ~300–350 righe**.
- Logica modulare:
  - hook per stato/azioni
  - componenti UI per rendering
- No refactor cosmetici: si cambia solo per bug o per requisiti.

## Note PWA

- `registerSW()` avviene in `src/main.tsx`.
- In dev viene eseguito `unregisterSwInDevOnce()` per evitare cache stale durante sviluppo.

## Note stato attuale

- Architettura ibrida:
  - Home/Admin settings con persistenza locale.
  - `/admina` predisposta per CRUD su Supabase con fallback locale.
- Modello vino esteso (`purchasePrice`, `salePrice`, `warehouse`, `margin`, `notes`):
  - `warehouse` e `margin` sono calcolati automaticamente.
