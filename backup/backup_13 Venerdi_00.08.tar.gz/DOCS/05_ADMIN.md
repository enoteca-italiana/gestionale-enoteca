# Admin

Ultimo aggiornamento: **13/03/2026 00:07 CET**.

## Accesso

- Route: `/admin`
- Password:
  - default `1909` (hashata e salvata localmente)
  - modificabile in Admin

Hook: `apps/scarichi-vini/src/pages/admin/useAdminAuth.ts`

- salva hash in localStorage
- sessione valida ~12h (`authedUntil`)

## Navigazione admin

`AdminGate` gestisce le sezioni:

- home admin (menu)
- settings
- history
- pending

La Bottom Nav operativa mostra:

- `Home` (`/`)
- `Archivio` (`/admina`)

## Settings

File: `AdminSettings.tsx`

Toggle:

- Conferma finale
- Nome utente per scarico

Nota: le settings notificano aggiornamenti in-tab via evento custom `scarichi:settingsChanged`.

## Storico

File: `AdminHistory.tsx`

- mostra solo sessioni inviate correttamente.
- reset storico:
  - doppia conferma.

## Sospesi

File: `AdminPending.tsx`

- lista sessioni in coda.
- delete singolo con conferma.
- delete tutti con conferma.

## Reset totale

In `AdminSettings.tsx`:

- doppia conferma
- chiama `hardResetAll()`
- cancella inventario + storico + sospesi

## Archivio vini (`/admina`)

Route dedicata per gestione archivio desktop-first.

Componenti:

- `pages/admina/WineAdminPage.tsx`
- `pages/admina/components/AdminArchiveToolbar.tsx`
- `pages/admina/components/AdminArchiveTable.tsx`
- `pages/admina/components/WineArchiveFormModal.tsx`

Funzioni:

- ricerca e filtri (testo, categoria, disponibilità)
- filtri su singola riga desktop con box statistiche compatto tra filtro giacenze e pulsante `Aggiungi vino`
- CRUD vini
- tabella estesa con header sticky
- righe alternate + separatori verticali
- riempimento automatico con righe vuote fino al fondo area tabella
- box statistiche: `Disponibili` in tono verde, `Esauriti` in tono rosso

Regole business:

- `Magazzino = Acquisto × Q.tà`
- `Margine = Vendita − Acquisto`
- q.tà `0` evidenziata in rosso acceso
